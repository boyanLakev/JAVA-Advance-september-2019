public class Tyre {
    double pressure;
    int age;

    public Tyre(double pressure, int age) {
        this.pressure = pressure;
        this.age = age;
    }
}
