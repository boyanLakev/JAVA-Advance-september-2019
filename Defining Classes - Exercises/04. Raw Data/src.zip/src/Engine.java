public class Engine {
    int speed;
    int power;

    public Engine(int speed, int power) {
        this.speed = speed;
        this.power = power;
    }
}
